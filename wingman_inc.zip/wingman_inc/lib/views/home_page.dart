import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wingman_inc/services/auth_service.dart';
import 'package:wingman_inc/views/login_screen.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text("home page"),
        actions: [
          IconButton(onPressed: (){
            TokenManager.removeToken().then((value) {
              Navigator.pushReplacement(context, MaterialPageRoute(builder: (context)=>const LoginScreen()));
            });
          }, icon: Icon(Icons.logout))
        ],
      ),
      body: const Center(
        child: Text("HomePage"),
      ),
    );
  }
}
