import 'dart:convert';
import 'dart:math';

import 'package:get/get.dart';
import 'package:http/http.dart' as http;
import 'package:wingman_inc/models/login_model.dart';
import 'package:wingman_inc/models/verify_otp_model.dart';
import 'package:wingman_inc/services/auth_service.dart';

import '../models/register_model.dart';

class AuthController extends GetxController {
  String token = TokenManager.getToken().toString();
  Map<String, String> headers = {
    'Authorization': 'Bearer ${TokenManager.getToken().toString()}',
  };
  Future<LoginModel> login(String phone) async {
    var response = await http.post(
        Uri.parse("https://test-otp-api.7474224.xyz/sendotp.php"),
        body: {"mobile": phone});
    var data = json.decode(response.body);
    if (response.statusCode == 200) {
      print(data);
    }
    LoginModel loginModel = LoginModel.fromJson(data);
    return loginModel;
  }

  Future<VerifyOtpModel> verifyOtp(String reqId, String otp) async {
    var response = await http.post(
        Uri.parse("http://localhost/sample-api-login/verifyotp.php"),
        body: {"request_id": reqId, "code": otp});
    var data = json.decode(response.body);
    if (response.statusCode == 200) {
      print(data);
    }
    VerifyOtpModel verifyOtpModel = VerifyOtpModel.fromJson(data);
    return verifyOtpModel;
  }

  Future<RegisterModel> register(String name, String email) async {
    print(TokenManager.getToken().toString());
    var response = await http.post(
        Uri.parse("https://test-otp-api.7474224.xyz/profilesubmit.php"),
        headers: headers,
        body: {"name": name, "email": email});
    var data = jsonDecode(response.body);
    if(response.statusCode==200){
      print(data);
    }
    RegisterModel registerModel = RegisterModel.fromJson(data);
    return registerModel;
  }
}
