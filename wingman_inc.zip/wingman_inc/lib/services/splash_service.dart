import 'dart:async';

import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:wingman_inc/services/auth_service.dart';
import 'package:wingman_inc/views/login_screen.dart';

import '../views/home_page.dart';

class SplashService{
  void isLogin(BuildContext context){
    final user = TokenManager.getToken();
    if(user != null){
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=> const HomePage()));
      });
    }else{
      Timer(const Duration(seconds: 3), () {
        Navigator.push(context, MaterialPageRoute(builder: (context)=> const LoginScreen()));
      });    }

  }
}