// To parse this JSON data, do
//
//     final verifyOtpModel = verifyOtpModelFromJson(jsonString);

import 'dart:convert';

VerifyOtpModel verifyOtpModelFromJson(String str) => VerifyOtpModel.fromJson(json.decode(str));

String verifyOtpModelToJson(VerifyOtpModel data) => json.encode(data.toJson());

class VerifyOtpModel {
  bool status;
  bool profileExists;
  String jwt;

  VerifyOtpModel({
    required this.status,
    required this.profileExists,
    required this.jwt,
  });

  factory VerifyOtpModel.fromJson(Map<String, dynamic> json) => VerifyOtpModel(
    status: json["status"],
    profileExists: json["profile_exists"],
    jwt: json["jwt"],
  );

  Map<String, dynamic> toJson() => {
    "status": status,
    "profile_exists": profileExists,
    "jwt": jwt,
  };
}
