package com.example.wingman_inc

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
